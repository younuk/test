package kr.ac.ut.eHr.domain;

public class StatSearch{
    private String srchDegree;
    private String srchRank;
    private String srchOrgnz;
    private String srchSpecial;

    public String getSrchSpecial() {
        return srchSpecial;
    }
    public void setSrchSpecial(String srchSpecial) {
        this.srchSpecial = srchSpecial;
    }
    public String getSrchDegree() {
        return srchDegree;
    }
    public void setSrchDegree(String srchDegree) {
        this.srchDegree = srchDegree;
    }
    public String getSrchRank() {
        return srchRank;
    }
    public void setSrchRank(String srchRank) {
        this.srchRank = srchRank;
    }
    public String getSrchOrgnz() {
        return srchOrgnz;
    }
    public void setSrchOrgnz(String srchOrgnz) {
        this.srchOrgnz = srchOrgnz;
    }

}