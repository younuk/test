package kr.ac.ut.eHr.domain;

public class Orgnz{
    private String orgnzId;
    private String name;
    private String dept1Nrm;
    private String dept1Vcc;
    private String dept1Now;
    private String dept2Nrm;
    private String dept2Vcc;
    private String dept2Now;
    private String dept3Nrm;
    private String dept3Vcc;
    private String dept3Now;
    private String dept4Nrm;
    private String dept4Vcc;
    private String dept4Now;
    private String dept5Nrm;
    private String dept5Vcc;
    private String dept5Now;
    private String dept6Nrm;
    private String dept6Vcc;
    private String dept6Now;
    private String dept7Nrm;
    private String dept7Vcc;
    private String dept7Now;
    private String special;
    private String applOrgnzYn;

    private String nrmTotal;
    private String vccTotal;
    private String psbTotal;
    private String nowTotal;

    public String getPsbTotal() {
        return psbTotal;
    }
    public void setPsbTotal(String psbTotal) {
        this.psbTotal = psbTotal;
    }
    public String getDept6Nrm() {
        return dept6Nrm;
    }
    public void setDept6Nrm(String dept6Nrm) {
        this.dept6Nrm = dept6Nrm;
    }
    public String getDept6Vcc() {
        return dept6Vcc;
    }
    public void setDept6Vcc(String dept6Vcc) {
        this.dept6Vcc = dept6Vcc;
    }
    public String getDept6Now() {
        return dept6Now;
    }
    public void setDept6Now(String dept6Now) {
        this.dept6Now = dept6Now;
    }
    public String getDept7Nrm() {
        return dept7Nrm;
    }
    public void setDept7Nrm(String dept7Nrm) {
        this.dept7Nrm = dept7Nrm;
    }
    public String getDept7Vcc() {
        return dept7Vcc;
    }
    public void setDept7Vcc(String dept7Vcc) {
        this.dept7Vcc = dept7Vcc;
    }
    public String getDept7Now() {
        return dept7Now;
    }
    public void setDept7Now(String dept7Now) {
        this.dept7Now = dept7Now;
    }
    public String getDept1Now() {
        return dept1Now;
    }
    public void setDept1Now(String dept1Now) {
        this.dept1Now = dept1Now;
    }
    public String getDept2Now() {
        return dept2Now;
    }
    public void setDept2Now(String dept2Now) {
        this.dept2Now = dept2Now;
    }
    public String getDept3Now() {
        return dept3Now;
    }
    public void setDept3Now(String dept3Now) {
        this.dept3Now = dept3Now;
    }
    public String getDept4Now() {
        return dept4Now;
    }
    public void setDept4Now(String dept4Now) {
        this.dept4Now = dept4Now;
    }
    public String getDept5Now() {
        return dept5Now;
    }
    public void setDept5Now(String dept5Now) {
        this.dept5Now = dept5Now;
    }
    public String getNowTotal() {
        return nowTotal;
    }
    public void setNowTotal(String nowTotal) {
        this.nowTotal = nowTotal;
    }
    public String getSpecial() {
        return special;
    }
    public void setSpecial(String special) {
        this.special = special;
    }
    public String getNrmTotal() {
        return nrmTotal;
    }
    public void setNrmTotal(String nrmTotal) {
        this.nrmTotal = nrmTotal;
    }
    public String getVccTotal() {
        return vccTotal;
    }
    public void setVccTotal(String vccTotal) {
        this.vccTotal = vccTotal;
    }
    public String getOrgnzId() {
        return orgnzId;
    }
    public void setOrgnzId(String orgnzId) {
        this.orgnzId = orgnzId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDept1Nrm() {
        return dept1Nrm;
    }
    public void setDept1Nrm(String dept1Nrm) {
        this.dept1Nrm = dept1Nrm;
    }
    public String getDept1Vcc() {
        return dept1Vcc;
    }
    public void setDept1Vcc(String dept1Vcc) {
        this.dept1Vcc = dept1Vcc;
    }
    public String getDept2Nrm() {
        return dept2Nrm;
    }
    public void setDept2Nrm(String dept2Nrm) {
        this.dept2Nrm = dept2Nrm;
    }
    public String getDept2Vcc() {
        return dept2Vcc;
    }
    public void setDept2Vcc(String dept2Vcc) {
        this.dept2Vcc = dept2Vcc;
    }
    public String getDept3Nrm() {
        return dept3Nrm;
    }
    public void setDept3Nrm(String dept3Nrm) {
        this.dept3Nrm = dept3Nrm;
    }
    public String getDept3Vcc() {
        return dept3Vcc;
    }
    public void setDept3Vcc(String dept3Vcc) {
        this.dept3Vcc = dept3Vcc;
    }
    public String getDept4Nrm() {
        return dept4Nrm;
    }
    public void setDept4Nrm(String dept4Nrm) {
        this.dept4Nrm = dept4Nrm;
    }
    public String getDept4Vcc() {
        return dept4Vcc;
    }
    public void setDept4Vcc(String dept4Vcc) {
        this.dept4Vcc = dept4Vcc;
    }
    public String getDept5Nrm() {
        return dept5Nrm;
    }
    public void setDept5Nrm(String dept5Nrm) {
        this.dept5Nrm = dept5Nrm;
    }
    public String getDept5Vcc() {
        return dept5Vcc;
    }
    public void setDept5Vcc(String dept5Vcc) {
        this.dept5Vcc = dept5Vcc;
    }
    public String getApplOrgnzYn() {
        return applOrgnzYn;
    }
    public void setApplOrgnzYn(String applOrgnzYn) {
        this.applOrgnzYn = applOrgnzYn;
    }
}