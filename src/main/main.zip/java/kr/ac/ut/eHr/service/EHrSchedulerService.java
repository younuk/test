package kr.ac.ut.eHr.service;

public interface EHrSchedulerService {
    void updatePsnnlBatchStat();

    void updatePsnnl();
}
